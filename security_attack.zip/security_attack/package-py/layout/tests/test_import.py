from package.unittest import *

class TestImport(TestCase):
    def test_import(self):
        import %(name)s

        self.assertTrue(True, '%(name)s module imported cleanly')

if __name__ == '__main__':
    main()
